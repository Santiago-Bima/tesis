package com.tesis.queseria_la_charito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueseriaLaCharitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueseriaLaCharitoApplication.class, args);
	}

}
