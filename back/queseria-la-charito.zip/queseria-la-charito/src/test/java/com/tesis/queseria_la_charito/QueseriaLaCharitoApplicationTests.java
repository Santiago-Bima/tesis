package com.tesis.queseria_la_charito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueseriaLaCharitoApplicationTests {

	@Test
	void contextLoads() {
	}

}
